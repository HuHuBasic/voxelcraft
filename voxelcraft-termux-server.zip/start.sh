# VoxelCraft Termux 启动脚本
# 在 Termux 中运行: bash start.sh

echo "启动 VoxelCraft 服务端..."
cd ~/voxelcraft-server

# 获取本机局域网 IP
LOCAL_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}')
if [ -z "$LOCAL_IP" ]; then
    LOCAL_IP="127.0.0.1"
fi

echo ""
echo "========================================"
echo "  VoxelCraft 方块世界"
echo "  局域网地址: ws://$LOCAL_IP:8080"
echo "========================================"
echo ""

node server.js
