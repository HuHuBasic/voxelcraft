# VoxelCraft Cloudflare Tunnel 脚本 (Termux 安卓版)
# 需要先安装 cloudflared: pkg install cloudflared
# 启动: bash tunnel.sh

LOCAL_PORT=${1:-8080}

echo "========================================"
echo "  VoxelCraft Cloudflare Tunnel"
echo "  本地端口: $LOCAL_PORT"
echo "========================================"
echo ""

# 启动隧道
cloudflared tunnel --url "http://localhost:$LOCAL_PORT" 2>&1 | while read line; do
    echo "$line"
    # 提取 trycloudflare.com 地址
    if echo "$line" | grep -oP 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' > /dev/null 2>&1; then
        ADDR=$(echo "$line" | grep -oP 'https://[a-zA-Z0-9-]+\.trycloudflare\.com')
        echo ""
        echo "========================================"
        echo "  公网地址: $ADDR"
        echo "  分享给朋友即可跨网联机！"
        echo "========================================"
    fi
done
