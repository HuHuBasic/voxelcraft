# VoxelCraft Termux 一键安装脚本
# 在 Termux 中运行: bash install.sh

echo "========================================"
echo "  VoxelCraft 方块世界 - Termux 安装"
echo "========================================"
echo ""

# 更新包管理器
echo "[1/3] 更新包管理器..."
pkg update -y && pkg upgrade -y

# 安装 Node.js
echo "[2/3] 安装 Node.js..."
pkg install nodejs -y

# 安装依赖
echo "[3/3] 安装 npm 依赖..."
cd ~/voxelcraft-server
npm install ws express body-parser

echo ""
echo "========================================"
echo "  安装完成！"
echo "  启动服务器: cd ~/voxelcraft-server && node server.js"
echo "========================================"
