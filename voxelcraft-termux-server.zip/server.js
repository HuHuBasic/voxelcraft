// ================================================================
// VoxelCraft 方块世界 - Termux 安卓服务端 v1.3
// 在 Termux 上运行：node server.js
// ================================================================
const { WebSocketServer } = require('ws');
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;
const TICK_RATE = 50;
const DATA_FILE = path.join(__dirname, 'users.json');

const PROTOCOL_VERSION = 1;
const SERVER_VERSION = '1.3.0';
const MIN_CLIENT_PROTOCOL = 1;
const GAME_COMPAT = '1.0.0+';

const COLORS = [
  '#e74c3c', '#3498db', '#2ecc71', '#f39c12', '#9b59b6',
  '#1abc9c', '#e67e22', '#2980b9', '#27ae60', '#d35400',
  '#8e44ad', '#16a085', '#c0392b', '#f1c40f', '#7f8c8d',
];

let users = {};
let tokens = {};
let players = new Map();
let worldBlocks = new Map();
let nextId = 1;
let nextCid = 1;
let hosts = {};

// ---- OP 系统 ----
let opNames = new Set();           // 管理员用户名列表
let whitelist = [];               // 白名单
let banList = [];                 // 封禁列表
let spawnX = 16, spawnY = 12, spawnZ = 16;
let worldTime = 6000;             // 世界时间 (0-24000)
let worldMode = 0;                // 0=生存, 1=创造
let explosionProtect = false;
let DATA_OP_FILE = path.join(__dirname, 'op_data.json');

function hash(pwd) { return crypto.createHash('sha256').update(pwd).digest('hex'); }
function loadUsers() { try { users = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { users = {}; } }
function saveUsers() { fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2)); }

function loadOpData() {
  try {
    const d = JSON.parse(fs.readFileSync(DATA_OP_FILE, 'utf8'));
    if (d.opNames) opNames = new Set(d.opNames);
    if (d.whitelist) whitelist = d.whitelist;
    if (d.banList) banList = d.banList;
    if (d.spawnX != null) spawnX = d.spawnX;
    if (d.spawnY != null) spawnY = d.spawnY;
    if (d.spawnZ != null) spawnZ = d.spawnZ;
    if (d.worldTime != null) worldTime = d.worldTime;
    if (d.worldMode != null) worldMode = d.worldMode;
    if (d.explosionProtect != null) explosionProtect = d.explosionProtect;
  } catch { /* 首次运行，无数据 */ }
}
function saveOpData() {
  fs.writeFileSync(DATA_OP_FILE, JSON.stringify({
    opNames: [...opNames], whitelist, banList,
    spawnX, spawnY, spawnZ, worldTime, worldMode, explosionProtect
  }, null, 2));
}

loadUsers();
loadOpData();

// ---- HTTP API ----
const app = express();
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.post('/api/register', (req, res) => {
  const { username, password, name } = req.body;
  if (!username || !password) return res.json({ ok: false, msg: '请填写账号和密码' });
  if (!/^[a-zA-Z0-9_\u4e00-\u9fa5]{2,16}$/.test(username)) return res.json({ ok: false, msg: '账号需2-16位字母/数字/中文' });
  if (password.length < 4 || password.length > 20) return res.json({ ok: false, msg: '密码需4-20位' });
  if (users[username]) return res.json({ ok: false, msg: '账号已存在' });
  users[username] = { username, passwordHash: hash(password), name: (name || username).substring(0, 12), createdAt: Date.now() };
  saveUsers();
  const token = crypto.randomBytes(32).toString('hex');
  tokens[token] = username;
  console.log(`[注册] ${username}`);
  res.json({ ok: true, token, user: users[username] });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.json({ ok: false, msg: '请填写账号和密码' });
  const user = users[username];
  if (!user) return res.json({ ok: false, msg: '账号不存在' });
  if (user.passwordHash !== hash(password)) return res.json({ ok: false, msg: '密码错误' });
  const token = crypto.randomBytes(32).toString('hex');
  tokens[token] = username;
  console.log(`[登录] ${username}`);
  res.json({ ok: true, token, user });
});

app.get('/api/check', (req, res) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const username = tokens[token];
  if (!username || !users[username]) return res.json({ ok: false });
  res.json({ ok: true, user: users[username] });
});

app.get('/api/ping', (req, res) => res.json({ ok: true, t: Date.now() }));

app.get('/api/version', (req, res) => res.json({
  ok: true, protocol: PROTOCOL_VERSION, server: SERVER_VERSION,
  minClient: MIN_CLIENT_PROTOCOL, gameCompat: GAME_COMPAT, compatible: true, crossNetwork: true,
}));

// ---- WS 服务器 ----
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n========================================`);
  console.log(`  VoxelCraft 方块世界 v${SERVER_VERSION}`);
  console.log(`  服务端已启动 → http://0.0.0.0:${PORT}`);
  console.log(`  在线玩家: 0`);
  console.log(`========================================\n`);
});

const wss = new WebSocketServer({ server, perMessageDeflate: false });

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://localhost');
  const token = url.searchParams.get('token') || '';
  const username = tokens[token];
  if (!username || !users[username]) {
    socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
    socket.destroy();
    return;
  }
  req._username = username;
});

function broadcast(data, exclude) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(c => { if (c.readyState === 1 && c !== exclude) c.send(msg); });
}
function broadcastAll(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(c => { if (c.readyState === 1) c.send(msg); });
}

function publicPlayers() {
  const list = [];
  for (const [w, p] of players) {
    if (!p.isHost && !p.roomClient) list.push({ id: p.id, name: p.name, color: p.color, username: p.username, x: p.x, y: p.y, z: p.z, pitch: p.pitch, yaw: p.yaw });
  }
  return list;
}
function roomClients(room) {
  const list = [];
  for (const [w, p] of players) if (p.roomClient && p.room === room) list.push(w);
  return list;
}
function routeHostToRoom(room, data) {
  const clients = roomClients(room);
  let targets = clients;
  if (Array.isArray(data.to)) {
    const cids = new Set(data.to.map(Number));
    targets = clients.filter(c => { const p = players.get(c); return p && cids.has(p.cid); });
  } else if (typeof data.to === 'number') {
    targets = clients.filter(c => { const p = players.get(c); return p && p.cid === data.to; });
  }
  const out = Object.assign({}, data); delete out.to;
  const msg = JSON.stringify(out);
  targets.forEach(c => { if (c.readyState === 1) c.send(msg); });
}
function sendPublicInit(ws) {
  const p = players.get(ws); if (!p) return;
  ws.send(JSON.stringify({
    type: 'init', playerId: p.id, color: p.color, username: p.username, name: p.name,
    protocol: PROTOCOL_VERSION, serverVersion: SERVER_VERSION,
    blocks: (() => { const b = []; for (const [k, id] of worldBlocks) b.push([k, id]); return b; })(),
    players: publicPlayers(),
  }));
}

// ---- OP 命令处理 ----
function handleCommand(player, cmd, args) {
  const username = player.username;
  const isOwner = (username === 'admin' || username === 'root');
  const isAdmin = opNames.has(username);
  const isOp = isOwner || isAdmin;

  switch (cmd) {
    case 'kick': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; if (!target) return '§e用法: /kick <玩家名>';
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) {
          ws.send(JSON.stringify({ type: 'kick_self', msg: '你被踢出服务器' }));
          setTimeout(() => ws.close(), 100);
          return `§a已踢出 ${target}`;
        }
      }
      return `§c找不到玩家 ${target}`;
    }
    case 'ban': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; if (!target) return '§e用法: /ban <玩家名>';
      if (!banList.includes(target)) banList.push(target);
      saveOpData();
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) {
          ws.send(JSON.stringify({ type: 'kick_self', msg: '你已被封禁' }));
          setTimeout(() => ws.close(), 100);
        }
      }
      return `§a已封禁 ${target}`;
    }
    case 'unban': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; if (!target) return '§e用法: /unban <玩家名>';
      banList = banList.filter(n => n !== target);
      saveOpData();
      return `§a已解封 ${target}`;
    }
    case 'mute': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; if (!target) return '§e用法: /mute <玩家名>';
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) { p._muted = true; return `§a已禁言 ${target}`; }
      }
      return `§c找不到玩家 ${target}`;
    }
    case 'unmute': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; if (!target) return '§e用法: /unmute <玩家名>';
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) { p._muted = false; return `§a已解除禁言 ${target}`; }
      }
      return `§c找不到玩家 ${target}`;
    }
    case 'broadcast': {
      if (!isOp) return '§c权限不足';
      const msg = args.join(' '); if (!msg) return '§e用法: /broadcast <消息>';
      broadcastAll({ type: 'chat', name: '§6[广播]', msg: `§e${msg}` });
      return `§a广播已发送`;
    }
    case 'clearchat': {
      if (!isOp) return '§c权限不足';
      broadcastAll({ type: 'clear_chat' });
      return `§a聊天已清空`;
    }
    case 'tp': {
      if (!isOp) return '§c权限不足';
      const target = args[0];
      if (!target) return '§e用法: /tp <玩家名>';
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) {
          player.x = p.x; player.y = p.y; player.z = p.z;
          player._ws.send(JSON.stringify({ type: 'teleport', x: p.x, y: p.y, z: p.z }));
          return `§a已传送到 ${target}`;
        }
      }
      return `§c找不到玩家 ${target}`;
    }
    case 'spawn': {
      if (!isOp) return '§c权限不足';
      player.x = spawnX; player.y = spawnY; player.z = spawnZ;
      player._ws.send(JSON.stringify({ type: 'teleport', x: spawnX, y: spawnY, z: spawnZ }));
      return '§a已传送到出生点';
    }
    case 'setspawn': {
      if (!isOp) return '§c权限不足';
      spawnX = player.x; spawnY = player.y; spawnZ = player.z;
      saveOpData();
      return `§a出生点已设为 (${Math.round(spawnX)}, ${Math.round(spawnY)}, ${Math.round(spawnZ)})`;
    }
    case 'time': {
      if (!isOp) return '§c权限不足';
      const t = args[0];
      if (t === 'day') { worldTime = 1000; saveOpData(); broadcastAll({ type: 'time_change', time: worldTime }); return '§a时间已设为白天'; }
      if (t === 'night') { worldTime = 13000; saveOpData(); broadcastAll({ type: 'time_change', time: worldTime }); return '§a时间已设为夜晚'; }
      const n = parseInt(t);
      if (!isNaN(n) && n >= 0 && n <= 24000) { worldTime = n; saveOpData(); broadcastAll({ type: 'time_change', time: worldTime }); return `§a时间已设为 ${n}`; }
      return '§e用法: /time <day|night|0-24000>';
    }
    case 'gamemode': {
      if (!isOp) return '§c权限不足';
      const m = args[0];
      if (m === '0' || m === 'survival') { worldMode = 0; saveOpData(); broadcastAll({ type: 'gamemode_change', mode: 0 }); return '§a游戏模式已设为生存'; }
      if (m === '1' || m === 'creative') { worldMode = 1; saveOpData(); broadcastAll({ type: 'gamemode_change', mode: 1 }); return '§a游戏模式已设为创造'; }
      return '§e用法: /gamemode <0|1|survival|creative>';
    }
    case 'give': {
      if (!isOp) return '§c权限不足';
      const target = args[0]; const item = args[1]; const count = parseInt(args[2]) || 1;
      if (!target || !item) return '§e用法: /give <玩家名> <物品id> [数量]';
      for (const [ws, p] of players) {
        if (p.name === target || p.username === target) {
          ws.send(JSON.stringify({ type: 'give_item', item, count }));
          return `§a已给 ${target} ${item} x${count}`;
        }
      }
      return `§c找不到玩家 ${target}`;
    }
    case 'list': {
      const names = [];
      for (const [ws, p] of players) {
        if (!p.isHost) names.push(p.name + (opNames.has(p.username) ? '§9[OP]' : ''));
      }
      return `§e在线玩家 (${names.length}): §f${names.join(', ') || '无'}`;
    }
    case 'banlist': {
      if (!isOp) return '§c权限不足';
      return `§e封禁列表: §c${banList.join(', ') || '无'}`;
    }
    case 'op': {
      if (!isOwner) return '§c仅服务器所有者可执行此命令';
      const target = args[0]; if (!target) return '§e用法: /op <玩家名>';
      opNames.add(target); saveOpData();
      return `§a已将 ${target} 设为管理员`;
    }
    case 'deop': {
      if (!isOwner) return '§c仅服务器所有者可执行此命令';
      const target = args[0]; if (!target) return '§e用法: /deop <玩家名>';
      opNames.delete(target); saveOpData();
      return `§a已移除 ${target} 的管理员权限`;
    }
    case 'whitelist': {
      if (!isOp) return '§c权限不足';
      const sub = args[0];
      if (sub === 'on') { whitelist = ['*']; saveOpData(); return '§a白名单已开启'; }
      if (sub === 'off') { whitelist = []; saveOpData(); return '§a白名单已关闭'; }
      if (sub === 'add' && args[1]) { if (whitelist.length === 0) whitelist = ['*']; whitelist.push(args[1]); saveOpData(); return `§a已将 ${args[1]} 加入白名单`; }
      if (sub === 'remove' && args[1]) { whitelist = whitelist.filter(n => n !== args[1]); saveOpData(); return `§a已将 ${args[1]} 移出白名单`; }
      return `§e白名单状态: ${whitelist.length > 0 ? '§a开启' : '§c关闭'}\n§e用法: /whitelist <on|off|add|remove> [玩家名]`;
    }
    case 'explosion': {
      if (!isOp) return '§c权限不足';
      explosionProtect = !explosionProtect; saveOpData();
      return `§a爆炸保护已${explosionProtect ? '开启' : '关闭'}`;
    }
    case 'help': {
      return `§6==== VoxelCraft 命令帮助 ====
§e/kick <玩家> §7- 踢出玩家
§e/ban <玩家> §7- 封禁玩家
§e/unban <玩家> §7- 解封玩家
§e/mute <玩家> §7- 禁言玩家
§e/unmute <玩家> §7- 解除禁言
§e/broadcast <消息> §7- 全服广播
§e/clearchat §7- 清空聊天
§e/tp <玩家> §7- 传送到玩家
§e/spawn §7- 回到出生点
§e/setspawn §7- 设置出生点
§e/time <day|night|0-24000> §7- 设置时间
§e/gamemode <0|1> §7- 设置游戏模式
§e/give <玩家> <物品> [数量] §7- 给玩家物品
§e/list §7- 查看在线玩家
§e/banlist §7- 查看封禁列表
§e/op <玩家> §7- 设为管理员(仅所有者)
§e/deop <玩家> §7- 移除管理员(仅所有者)
§e/whitelist <on|off|add|remove> §7- 白名单管理
§e/explosion §7- 切换爆炸保护
§e/help §7- 显示此帮助`;
    }
    default:
      return `§c未知命令: /${cmd}。输入 /help 查看可用命令`;
  }
}

wss.on('connection', (ws, req) => {
  const username = req._username || 'unknown';
  const user = users[username] || {};

  // 封禁检查
  if (banList.includes(username)) {
    ws.send(JSON.stringify({ type: 'kick_self', msg: '你已被封禁' }));
    setTimeout(() => ws.close(), 100);
    return;
  }
  // 白名单检查
  if (whitelist.length > 0 && !whitelist.includes(username) && !whitelist.includes('*')) {
    ws.send(JSON.stringify({ type: 'kick_self', msg: '你不在白名单中' }));
    setTimeout(() => ws.close(), 100);
    return;
  }

  const playerId = nextId++;
  const color = COLORS[(playerId - 1) % COLORS.length];
  const isAdmin = opNames.has(username);
  const isOwner = (username === 'admin' || username === 'root');
  const player = {
    id: playerId, name: user.name || username, username, color,
    x: spawnX, y: spawnY, z: spawnZ, pitch: 0, yaw: 0,
    lastMove: 0, pv: 0, gv: '',
    isHost: false, roomClient: false, room: null, cid: 0,
    _handled: false, _muted: false, _ws: ws,
  };
  players.set(ws, player);
  console.log(`[+] ${player.name} (${username}) ID:${playerId}${isAdmin ? ' [OP]' : ''}`);

  ws._helloTimer = setTimeout(() => {
    if (!player._handled) {
      player._handled = true;
      sendPublicInit(ws);
      broadcast({ type: 'player_join', player: { id: playerId, name: player.name, color, username, x: player.x, y: player.y, z: player.z, pitch: 0, yaw: 0 } }, ws);
    }
  }, 1500);

  ws.on('message', (raw) => {
    let data; try { data = JSON.parse(raw.toString()); } catch { return; }
    if (!data || typeof data !== 'object') return;
    const type = typeof data.type === 'string' ? data.type : '';
    try {
      switch (type) {
        case 'hello': {
          player.pv = Number(data.pv) || 0;
          player.gv = typeof data.gv === 'string' ? data.gv : '';
          if (!player._handled) {
            player._handled = true; clearTimeout(ws._helloTimer);
            const room = typeof data.room === 'string' ? data.room.slice(0, 24) : '';
            if (room && hosts[room] && hosts[room].readyState === 1) {
              player.roomClient = true; player.room = room; player.cid = nextCid++;
              hosts[room].send(JSON.stringify({ type: 'room_client_join', cid: player.cid, name: player.name, username: player.username }));
            } else {
              if (room) ws.send(JSON.stringify({ type: 'room_missing', room }));
              sendPublicInit(ws);
              broadcast({ type: 'player_join', player: { id: playerId, name: player.name, color, username, x: player.x, y: player.y, z: player.z, pitch: 0, yaw: 0 } }, ws);
            }
          }
          break;
        }
        case 'host': {
          const room = typeof data.room === 'string' ? data.room.slice(0, 24) : '';
          if (!room) { ws.send(JSON.stringify({ type: 'host_err', msg: '房间名无效' })); break; }
          player._handled = true; clearTimeout(ws._helloTimer);
          player.isHost = true; player.room = room;
          hosts[room] = ws;
          ws.send(JSON.stringify({ type: 'host_ok', room, serverVersion: SERVER_VERSION, protocol: PROTOCOL_VERSION }));
          console.log(`[房主] ${player.name} 开房: ${room}`);
          break;
        }
        case 'chat': {
          if (!data.msg) break;
          const msg = String(data.msg).substring(0, 200);

          // 检查是否被禁言
          if (player._muted && !msg.startsWith('/')) {
            ws.send(JSON.stringify({ type: 'chat', name: '§c[系统]', msg: '你已被禁言' }));
            break;
          }

          // OP 命令
          if (msg.startsWith('/')) {
            const parts = msg.slice(1).split(/\s+/);
            const cmd = parts[0].toLowerCase();
            const args = parts.slice(1);
            const result = handleCommand(player, cmd, args);
            ws.send(JSON.stringify({ type: 'system', msg: result }));
            break;
          }

          if (player.isHost) {
            routeHostToRoom(player.room, { type: 'chat', name: data.name || '房主', msg });
          } else if (player.roomClient) {
            const h = hosts[player.room];
            if (h && h.readyState === 1) h.send(JSON.stringify(Object.assign({}, data, { _from: player.cid })));
          } else {
            broadcastAll({ type: 'chat', playerId, name: player.name, msg });
          }
          break;
        }
        case 'move': {
          if (typeof data.x === 'number') player.x = data.x;
          if (typeof data.y === 'number') player.y = data.y;
          if (typeof data.z === 'number') player.z = data.z;
          if (typeof data.pitch === 'number') player.pitch = data.pitch;
          if (typeof data.yaw === 'number') player.yaw = data.yaw;
          player.lastMove = Date.now();
          if (player.isHost) { routeHostToRoom(player.room, data); }
          else if (player.roomClient) { const h = hosts[player.room]; if (h && h.readyState === 1) h.send(JSON.stringify(Object.assign({}, data, { _from: player.cid }))); }
          break;
        }
        case 'set_name':
          if (data.name) {
            player.name = String(data.name).substring(0, 12);
            if (users[username]) { users[username].name = player.name; saveUsers(); }
            if (player.isHost) { routeHostToRoom(player.room, { type: 'player_name', name: player.name }); }
            else if (player.roomClient) { const h = hosts[player.room]; if (h && h.readyState === 1) h.send(JSON.stringify(Object.assign({}, data, { _from: player.cid }))); }
            else broadcastAll({ type: 'player_name', playerId, name: player.name });
          }
          break;
        case 'block_break': {
          const k = `${data.x},${data.y},${data.z}`;
          worldBlocks.delete(k);
          if (player.isHost) { routeHostToRoom(player.room, data); }
          else if (player.roomClient) { const h = hosts[player.room]; if (h && h.readyState === 1) h.send(JSON.stringify(Object.assign({}, data, { _from: player.cid }))); }
          else broadcast({ type: 'block_break', x: data.x, y: data.y, z: data.z, playerId }, ws);
          break;
        }
        case 'block_place': {
          const k = `${data.x},${data.y},${data.z}`;
          worldBlocks.set(k, data.blockId);
          if (player.isHost) { routeHostToRoom(player.room, data); }
          else if (player.roomClient) { const h = hosts[player.room]; if (h && h.readyState === 1) h.send(JSON.stringify(Object.assign({}, data, { _from: player.cid }))); }
          else broadcast({ type: 'block_place', x: data.x, y: data.y, z: data.z, blockId: data.blockId, playerId }, ws);
          break;
        }
        case 'init':
        case 'players_move':
        case 'player_join':
        case 'player_leave':
        case 'block_update':
          if (player.isHost) { routeHostToRoom(player.room, data); }
          break;
        default:
          if (player.isHost) { routeHostToRoom(player.room, data); }
          break;
      }
    } catch (e) {
      console.log(`[消息异常] ${player.name}: ${e.message}`);
    }
  });

  ws.on('close', () => {
    console.log(`[-] ${player.name} 离开`);
    if (player.isHost) {
      delete hosts[player.room];
      roomClients(player.room).forEach(c => { if (c.readyState === 1) c.send(JSON.stringify({ type: 'host_gone' })); });
    } else if (player.roomClient) {
      const h = hosts[player.room];
      if (h && h.readyState === 1) h.send(JSON.stringify({ type: 'room_client_leave', cid: player.cid }));
    } else {
      broadcastAll({ type: 'player_leave', playerId });
    }
    players.delete(ws);
  });
  ws.on('error', () => players.delete(ws));
});

setInterval(() => {
  const positions = [], now = Date.now();
  for (const [ws, p] of players) {
    if (p.isHost || p.roomClient) continue;
    if (now - p.lastMove < 2000) positions.push({ id: p.id, x: p.x, y: p.y, z: p.z, pitch: p.pitch, yaw: p.yaw });
  }
  if (positions.length > 0) broadcastAll({ type: 'players_move', players: positions });
}, TICK_RATE);
