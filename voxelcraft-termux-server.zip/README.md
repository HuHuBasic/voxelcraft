# VoxelCraft 方块世界 - Termux 服务端

## 安装步骤

### 1. 安装 Termux
- 打开 https://f-droid.org 下载 F-Droid
- 在 F-Droid 里搜索安装 **Termux**
- 或直接从 GitHub 下载: https://github.com/termux/termux-app/releases

### 2. 把服务端文件复制到 Termux
```bash
# 在 Termux 里运行:
termux-setup-storage   # 授权存储权限（会弹窗，点允许）
mkdir -p ~/voxelcraft-server
cp /sdcard/Download/server.js ~/voxelcraft-server/
cp /sdcard/Download/install.sh ~/voxelcraft-server/
cp /sdcard/Download/start.sh ~/voxelcraft-server/
```

### 3. 一键安装
```bash
cd ~/voxelcraft-server
bash install.sh
```

### 4. 启动服务器
```bash
bash start.sh
```

### 5. 客户端连接

**局域网连接** (同一 WiFi):
- 游戏里点「跨网联机」
- 输入服务器地址: `ws://你的手机IP:8080`
- 例如: `ws://192.168.1.5:8080`

**公网连接** (需要 Cloudflare Tunnel):
- 安装 cloudflared: `pkg install cloudflared`
- 运行: `cloudflared tunnel --url http://localhost:8080`
- 把显示的地址分享给朋友

### 常用命令

| 命令 | 说明 |
|------|------|
| `/help` | 查看所有命令 |
| `/kick 玩家名` | 踢出玩家 (OP) |
| `/ban 玩家名` | 封禁玩家 (OP) |
| `/list` | 查看在线玩家 |
| `/time day` | 设为白天 (OP) |
| `/gamemode creative` | 创造模式 (OP) |
| `/op 玩家名` | 设为管理员 (所有者) |

**默认所有者**: 注册名为 `admin` 的用户自动获得最高权限。
